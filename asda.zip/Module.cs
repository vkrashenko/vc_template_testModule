﻿using VirtoCommerce.Platform.Core.Modularity;

namespace $safeprojectname$
{
    public class Module : ModuleBase
    {
        public override void SetupDatabase()
        {
        }

        public override void Initialize()
        {
        }

        public override void PostInitialize()
        {
        }
    }
}