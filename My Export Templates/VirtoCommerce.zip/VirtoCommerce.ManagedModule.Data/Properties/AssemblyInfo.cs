﻿using System.Reflection;

[assembly: AssemblyTitle("$safeprojectname$")]
[assembly: AssemblyDescription("Virto Commerce Data API")]
