﻿using System.Reflection;

[assembly: AssemblyTitle("VirtoCommerce.Platform.Tests")]
[assembly: AssemblyDescription("")]
