﻿var moduleName = "VirtoCommerce.ManagedModule";

if (AppDependencies != undefined) {
    AppDependencies.push(moduleName);
}

angular.module(moduleName, [
    //enter module dependencies
]);